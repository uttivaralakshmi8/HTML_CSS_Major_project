# CSS Lab Project

This is a starter project for the 45 CSS tasks.
Each module contains placeholder HTML and CSS files that you can extend.
